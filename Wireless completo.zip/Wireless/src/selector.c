/*
 * selector.c
 *
 *  Created on: 10 feb 2020
 *      Author: nicola
 */

#include "selector.h"


void select(unsigned char* comm){
		if(check(comm, POWER))
			lcd_display(LCD_LINE8,"POWER");
		else if(check(comm, OFF))
			lcd_display(LCD_LINE8,"OFF");
		else if(check(comm, LEFT))
			lcd_display(LCD_LINE8,"<--");
		else if(check(comm, RIGHT))
			lcd_display(LCD_LINE8,"-->");
		else if(check(comm, FORWARD))
			lcd_display(LCD_LINE8,"FORWARD");
		else if(check(comm, BACKWARD))
			lcd_display(LCD_LINE8,"BACKWARD");
		else if(!check(comm, IGNORE))
			lcd_display(LCD_LINE8,"WRONG COMM");
	}

int check(unsigned char* comm, unsigned char* selected){
	int i=0;
	while(i<3 && comm[i]==selected[i])
		i++;
		if(i==3)
			return 1;
		else return 0;
}
