/*
 * parsing.c
 *
 *  Created on: 05 feb 2020
 *      Author: nicola
 */

#include "parsing.h"



int parser(unsigned char* buffer){

	if(isEqual(buffer,OK,0,'\n'))
		return 1;
	else if(isEqual(buffer,ERROR,0,'\n'))
		return -100;
	else return 0;
}

int isEqual(unsigned char* buf, unsigned char* control, int i, unsigned char check){
	if(control[i]!=check && buf[i]!=check && control[i]==buf[i] )
		{i++;

		return isEqual(buf,control,i,check);}
	else if(control[i]==buf[i])
		return 1;
	else return 0;
}

unsigned char* parseCommand(unsigned char* buf, unsigned char* comm){

	if(!isEqual(buf,PROTOCOL,0,':'))
		return "NNN";
	comm[0]=buf[9];
	comm[1]=buf[10];
	comm[2]=buf[11];
	return comm;
}

