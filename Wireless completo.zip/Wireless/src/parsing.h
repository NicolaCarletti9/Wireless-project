/*
 * parsing.h
 *
 *  Created on: 05 feb 2020
 *      Author: nicola
 */

#ifndef SRC_PARSING_H_
#define SRC_PARSING_H_


#include <stdbool.h>
#include <stdio.h>
#include <machine.h>
#include <string.h>
#include "platform.h"


#define OK ((unsigned char*)"OK\r\n")
#define ERROR ((unsigned char*)"ERROR\r\n")
#define PROTOCOL ((unsigned char*)"+IPD,0,3:")

int parser(unsigned char* buffer);
unsigned char* parseCommand(unsigned char* buffer, unsigned char* comm);
int isEqual(unsigned char* buf, unsigned char* control, int i, unsigned char check);
#endif /* SRC_PARSING_H_ */
