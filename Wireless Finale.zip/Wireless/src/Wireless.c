/***********************************************************************/
/*                                                                     */
/*  FILE        : Main.c                                   */
/*  DATE        :Tue, Oct 31, 2006                                     */
/*  DESCRIPTION :Main Program                                          */
/*  CPU TYPE    :                                                      */
/*                                                                     */
/*  NOTE:THIS IS A TYPICAL EXAMPLE.                                    */
/*                                                                     */
/***********************************************************************/
//#include "typedefine.h"

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <machine.h>
#include "platform.h"
#include "UART.h"


void main(void)
{

    /* Initialize LCD */
    lcd_initialize();

    /* Clear LCD */
    lcd_clear();

    /* Initialize UART */
    sci_uart_init();

    /*Wireless configuration*/
    wifi_init();

}
