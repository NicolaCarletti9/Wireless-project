
#include "UART.h"

#define SCI12_INT_LVL 3

static queue rx_queue;
static queue tx_queue;

queue * rx_queue_ptr;
queue * tx_queue_ptr;

int count=0;   /*counter used to check wireless settings*/
void sci_uart_init (void)
{
	uint16_t i;  /*for delay counter*/

	#ifdef PLATFORM_BOARD_RDKRX63N
                    SYSTEM.PRCR.WORD = 0xA50B; /* Protect off*/
    #endif
                    MPC.PWPR.BIT.B0WI = 0;  /*Unlock protection register */
                    MPC.PWPR.BIT.PFSWE = 1;  /*Unlock MPC registers */

                            /*clear ACSE Bit (All-Module Clock Stop Mode Enable*/
                              SYSTEM.MSTPCRA.BIT.ACSE = 0;
                     /*Cancel stop state of SCI2 Peripheral to enable writing to it*/
                    MSTP(SCI12) = 0;

          #ifdef PLATFORM_BOARD_RDKRX63N
                    SYSTEM.PRCR.WORD = 0XA500;  /*Protect on*/
          #endif
                    /*Clear bits TIE, RIE, RE, and TEIE in SCR to 0. Set CKE to internal.*/
                    SCI12.SCR.BYTE = 0X00;

          /*Set up the UART I/O port and pins*/
          MPC.PE2PFS.BYTE=0x4C; /*P23 of JN2 is RxD12*/
          MPC.PE1PFS.BYTE=0x4C; /*P22 of JN2 is TxD12*/


          PORTE.PDR.BIT.B1 = 1; /*TxD12 is output*/
          PORTE.PDR.BIT.B2 = 0; /*RxD12 is input*/
          PORTE.PMR.BIT.B1 = 1; /*TxD12 is peripheral*/
          PORTE.PMR.BIT.B2 = 1; /*RxD12 is peripheral*/


          /*Set data transfer format in Serial Mode Register (SMR)*/
          /*
           -Asynchronous Mode
           -8 bits
           -no parity
           -1 stop bit
           -PCLK clock (n = 0)*/
SCI12.SMR.BYTE = 0X00;

SCI12.SCMR.BIT.SMIF = 0; /*Set to 0 for serial communications interface mode */

/*Set bit rate register.
 * Example: set to 115200 baud
 * N = (PCLK Frequency) / (64 * 2^(2*n - 1) * Bit Rate) - 1
 * N = (48,000,000)    / (64 * 2^(2*0 - 1) * 115200) - 1
 * N = 12 */
SCI12.BRR = 48000000 / ((64/2)*BAUDRATE)-1;

/*Wait at least one bit interval*/
for (i=0; i<200;i++) /*assume minimum of 2 instructions at 98MHz? */
{
}

/*Clear IR bits for TIE, RIE and TEIE */
IR(SCI12, RXI12) = 0;      /*Clear any pending ISR.*/
IR(SCI12, TXI12) = 0;
IR(SCI12, TEI12) = 0;

IPR(SCI12, RXI12) = 4;      /*Set interrupt priority.*/
IPR(SCI12, TXI12) = 4;

IEN(SCI12, RXI12) = 0;   /*Disable interrupt sources */
IEN(SCI12, TXI12) = 0;
IEN(SCI12, TEI12) = 0;

/*Clear SCR* if Tx or Rx*/
SCI12.SCR.BYTE=0x00;

/*Enable RXI and TXI interrupt in SCI peripheral*/
SCI12.SCR.BIT.RIE = 1;

SCI12.SCR.BIT.TIE = 1;

SCI12.SCR.BIT.TEIE = 0;

SCI12.SCR.BIT.RE = 1;

SCI12.SCR.BIT.TE = 1;

sci_init_queues();

sci_rx_int_enable();

}


/*This function gives the AT commands to start the wireless module as TCP server*/
void wifi_init()
{
	unsigned char at_1[] ="AT+CWMODE=3\r\n";     //The module now is an AP and a wifi station
	unsigned char at_2[] ="AT+CIPMUX=1\r\n";     //The module now support multiple connections
	unsigned char at_3[] ="AT+CIPSERVER=1\r\n";  //The module now is a TCP server
	AT_settings(at_1);
	AT_settings(at_2);
	AT_settings(at_3);

	}

void sci_init_queues(void)
{
rx_queue_ptr = &rx_queue;
tx_queue_ptr = &tx_queue;

rx_queue_ptr->head = 0;
tx_queue_ptr->head = 0;

rx_queue_ptr->tail = 0;
tx_queue_ptr->tail = 0;

}

int queue_is_empty(queue * queue_ptr)
{
          if(queue_ptr->tail==0)
          return 1;
          else return 0;
          }


void reset_queue(queue * reset){
	reset->head = 0;
	reset->tail = 0;
	memset(reset->data_buffer, '\0', sizeof(reset->data_buffer));
}



void sci_tx_int_enable(void)

{
	IEN(SCI12, TXI12) = 1;
	IR(SCI12,TXI12)=1;
}

void sci_rx_int_enable(void)
{
	IEN(SCI12, RXI12) = 1;
}

void sci_tx_int_disable(void)
{
	IEN(SCI12, TXI12) = 0;


}

void sci_rx_int_disable(void)
{
	IEN(SCI12, RXI12) = 0;

}

/*This function copy the AT commands into the data buffer
 * and then enable the transmission interrupt*/
void AT_settings(unsigned char* buffer)
{int i=0;
for(i=0;i<100000;i++);
    		do{tx_queue_ptr->data_buffer[tx_queue_ptr->tail] = buffer[tx_queue_ptr->tail];
    		 tx_queue_ptr->tail++;
    		}while(buffer[tx_queue_ptr->tail]!=0);
/*Enable transmit interrupts in ICU */
	sci_tx_int_enable();

}



#pragma interrupt SCI12_TXI12_isr(vect = VECT_SCI12_TXI12, enable)
static void SCI12_TXI12_isr(void)
{

    if(!queue_is_empty(tx_queue_ptr))
    {
    	SCI12.TDR = tx_queue_ptr->data_buffer[tx_queue_ptr->head];
    	tx_queue_ptr->head++;

    	/*When a message is transmitted, the tx queue is reseted and the interrupt disabled */
    	if(SCI12.TDR=='\n')
    	    	reset_queue(tx_queue_ptr);
}
    else /*Niente da trasmettere*/
    {
    	sci_tx_int_disable();

    	}

}

#pragma interrupt SCI12_RXI12_isr(vect = VECT_SCI12_RXI12, enable)
static void SCI12_RXI12_isr(void){

int timeout;


timeout = 0;
while(SCI12.SSR.BIT.ORER && timeout++ <= 10000){ /* check for overrun error */
SCI12.SSR.BIT.ORER = 0; /* clear overrun error, repeats until condition cleared */
}
if(SCI12.SSR.BIT.FER)
SCI12.SSR.BIT.FER = 0; /* clear frame error */
if(SCI12.SSR.BIT.PER)
SCI12.SSR.BIT.PER = 0; /* clear parity error */

rx_queue_ptr->data_buffer[rx_queue_ptr->tail] = SCI12.RDR;
rx_queue_ptr->tail++;

/*The configuration of the module is correct only if count=3, otherwise if
 *count assume a negative value, the response to at least one AT command was ERROR.
 *While count assume a value between 0 and 2 he hasn't finish to send commands */
 if(count<3 && count>=0 && SCI12.RDR=='\n')
	{
	count+=parser(rx_queue_ptr->data_buffer);
	if(count<0)
		lcd_display(LCD_LINE4,"Config ERROR");
	else if(count==3)
		{lcd_display(LCD_LINE4,"WiFi Ready");
		}

	reset_queue(rx_queue_ptr);}

/*If the configuration is done, and it's correct, every string received is parsed,
 * looking for the next command*/
if(SCI12.RDR=='\n' && count==3)
{unsigned char comm[3];
	select(parseCommand(rx_queue_ptr->data_buffer,comm));
	reset_queue(rx_queue_ptr);
}


}

