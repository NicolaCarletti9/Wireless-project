/*
 * selector.h
 *
 *  Created on: 10 feb 2020
 *      Author: nicola
 */

#ifndef SRC_SELECTOR_H_
#define SRC_SELECTOR_H_

#include <machine.h>
#include "platform.h"
#include <stdint.h>

#define POWER ((unsigned char*)"POW")
#define OFF ((unsigned char*)"OFF")
#define RIGHT ((unsigned char*)"RIG")
#define LEFT ((unsigned char*)"LEF")
#define FORWARD ((unsigned char*)"FOR")
#define BACKWARD ((unsigned char*)"BAC")
#define UP ((unsigned char*)"UPP")
#define DOWN ((unsigned char*)"DWN")
/*PUT NEW COMMAND HERE*/
#define IGNORE ((unsigned char*)"NNN")

/*Example for a new define.
 *
 * #define EXAMPLE ((unsigned char*)"EXA")*/

void select(unsigned char* comm);
int check(unsigned char* comm, unsigned char* selected);

#endif /* SRC_SELECTOR_H_ */
