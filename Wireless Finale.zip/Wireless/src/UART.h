#ifndef UART_H //multiple inclusion guard
#define UART_H

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "platform.h"
#include "selector.h"
#include "parsing.h"

#define DIM_SERIAL_BUFFER 180

typedef struct {

	   unsigned char data_buffer[DIM_SERIAL_BUFFER];
	   unsigned int head;
	   unsigned int tail;
}queue;



#define BAUDRATE     115200 /* The same of the wireless module */



void 	AT_settings( unsigned char* buffer);
void    wifi_init();
void 	sci_uart_init(void);
void 	sci_init_queues(void);
void	sci_tx_int_enable(void);
void	sci_rx_int_enable(void);
void	sci_tx_int_disable(void);
void	sci_rx_int_disable(void);


int queue_is_empty(queue * queue_ptr);
void reset_queue(queue * rx_queue);

#endif


