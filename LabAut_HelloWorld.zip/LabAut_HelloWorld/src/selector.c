/*
 * selector.c
 *
 *  Created on: 10 feb 2020
 *      Author: nicola
 */

#include "selector.h"


void select(unsigned char* comm){
		if(check(comm, POWER))
			lcd_display(LCD_LINE8,"POWER");
		else if(check(comm, OFF))
			lcd_display(LCD_LINE8,"OFF");
		else if(check(comm, RISE))
			lcd_display(LCD_LINE8,"RISE");
		else if(check(comm, FALL))
			lcd_display(LCD_LINE8,"FALL");
		else if(!check(comm, IGNORE))
			lcd_display(LCD_LINE8,"WRONG COMM");
	}

int check(unsigned char* comm, unsigned char* selected){
	int i=0;
	while(i<3 && comm[i]==selected[i])
		i++;
		if(i==3)
			return 1;
		else return 0;
}
