/*
 * selector.h
 *
 *  Created on: 10 feb 2020
 *      Author: nicola
 */

#ifndef SRC_SELECTOR_H_
#define SRC_SELECTOR_H_

#include <machine.h>
#include "platform.h"
#include <stdint.h>

#define POWER ((unsigned char*)"POW")
#define OFF ((unsigned char*)"OFF")
#define RISE ((unsigned char*)"RIS")
#define FALL ((unsigned char*)"FAL")
#define IGNORE ((unsigned char*)"NNN")

void select(unsigned char* comm);
int check(unsigned char* comm, unsigned char* selected);

#endif /* SRC_SELECTOR_H_ */
