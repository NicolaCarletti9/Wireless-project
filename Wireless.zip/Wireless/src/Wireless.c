/***********************************************************************/
/*                                                                     */
/*  FILE        : Main.c                                   */
/*  DATE        :Tue, Oct 31, 2006                                     */
/*  DESCRIPTION :Main Program                                          */
/*  CPU TYPE    :                                                      */
/*                                                                     */
/*  NOTE:THIS IS A TYPICAL EXAMPLE.                                    */
/*                                                                     */
/***********************************************************************/
//#include "typedefine.h"

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <machine.h>
#include "platform.h"
#include "UART.h"
void main(void)
{unsigned char at_1[] ="AT+CWMODE=3\r\n";
unsigned char at_2[] ="AT+CIPMUX=1\r\n";
unsigned char at_3[] = "AT+CIPSERVER=1\r\n";
int i=0;
    /* Initialize LCD */
    lcd_initialize();

    /* Clear LCD */
    lcd_clear();

    sci_uart_init();


    sci_transmit(at_1);
    for(i=0; i<100000;i++);
    sci_transmit(at_2);
    for(i=0; i<100000;i++);
    sci_transmit(at_3);




    while (1)
    {

    }
}
